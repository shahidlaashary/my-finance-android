
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:cryptography/cryptography.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:math';
import 'package:local_auth/local_auth.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'dart:io';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyFinanceApp());
}

const ink = Color(0xFF101B35);
const navy = Color(0xFF172747);
const mint = Color(0xFF39C6A5);
const canvas = Color(0xFFF4F6FA);

class Txn {
  String id, title, category, accountId, type, date;
  double amount;
  Txn(this.id, this.title, this.category, this.accountId, this.type, this.amount, this.date);
  Map<String,dynamic> toJson() => {'id':id,'title':title,'category':category,'accountId':accountId,'type':type,'amount':amount,'date':date};
  factory Txn.fromJson(Map<String,dynamic> j) => Txn(j['id'],j['title'],j['category'],j['accountId'],j['type'],(j['amount'] as num).toDouble(),j['date']);
}

class Account {
  String id, name, kind;
  double opening;
  Account(this.id,this.name,this.kind,this.opening);
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'kind':kind,'opening':opening};
  factory Account.fromJson(Map<String,dynamic> j)=>Account(j['id'],j['name'],j['kind'],(j['opening'] as num).toDouble());
}

class AssetItem {
  String id,name,accountId,kind;
  double value;
  AssetItem(this.id,this.name,this.accountId,this.kind,this.value);
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'accountId':accountId,'kind':kind,'value':value};
  factory AssetItem.fromJson(Map<String,dynamic> j)=>AssetItem(j['id'],j['name'],j['accountId'],j['kind'],(j['value'] as num).toDouble());
}

class Goal {
  String id,name,accountId;
  double target,saved;
  Goal(this.id,this.name,this.accountId,this.target,this.saved);
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'accountId':accountId,'target':target,'saved':saved};
  factory Goal.fromJson(Map<String,dynamic> j)=>Goal(j['id'],j['name'],j['accountId'],(j['target'] as num).toDouble(),(j['saved'] as num).toDouble());
}

class Loan {
  String id,name,accountId,kind;
  double principal,remaining;
  Loan(this.id,this.name,this.accountId,this.kind,this.principal,this.remaining);
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'accountId':accountId,'kind':kind,'principal':principal,'remaining':remaining};
  factory Loan.fromJson(Map<String,dynamic> j)=>Loan(j['id'],j['name'],j['accountId'],j['kind'],(j['principal'] as num).toDouble(),(j['remaining'] as num).toDouble());
}


class Budget {
  String id, category;
  double limit;
  Budget(this.id,this.category,this.limit);
  Map<String,dynamic> toJson()=>{'id':id,'category':category,'limit':limit};
  factory Budget.fromJson(Map<String,dynamic> j)=>Budget(j['id'],j['category'],(j['limit'] as num).toDouble());
}
class RecurringItem {
  String id,title,category,accountId,type,frequency,nextDate;
  double amount;
  RecurringItem(this.id,this.title,this.category,this.accountId,this.type,this.amount,this.frequency,this.nextDate);
  Map<String,dynamic> toJson()=>{'id':id,'title':title,'category':category,'accountId':accountId,'type':type,'amount':amount,'frequency':frequency,'nextDate':nextDate};
  factory RecurringItem.fromJson(Map<String,dynamic> j)=>RecurringItem(j['id'],j['title'],j['category'],j['accountId'],j['type'],(j['amount'] as num).toDouble(),j['frequency'],j['nextDate']);
}

class MyFinanceApp extends StatefulWidget {
  const MyFinanceApp({super.key});
  @override State<MyFinanceApp> createState()=>_MyFinanceAppState();
}
class _MyFinanceAppState extends State<MyFinanceApp> {
  @override Widget build(BuildContext context)=>MaterialApp(
    debugShowCheckedModeBanner:false, title:'My Finance',
    theme:ThemeData(useMaterial3:true, scaffoldBackgroundColor:canvas,
      colorScheme:ColorScheme.fromSeed(seedColor:mint, brightness:Brightness.light),
      appBarTheme:const AppBarTheme(backgroundColor:canvas,foregroundColor:ink,elevation:0,centerTitle:false),
      cardTheme:CardThemeData(color:Colors.white,elevation:0,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(22))),
      inputDecorationTheme:InputDecorationTheme(filled:true,fillColor:canvas,border:OutlineInputBorder(borderRadius:BorderRadius.circular(14),borderSide:BorderSide.none))),
    home:const FinanceHome());
}

class FinanceHome extends StatefulWidget { const FinanceHome({super.key}); @override State<FinanceHome> createState()=>_FinanceHomeState(); }
class _FinanceHomeState extends State<FinanceHome> with WidgetsBindingObserver {
  int tab=0; bool loaded=false;
  List<Account> accounts=[];
  List<Txn> txns=[];
  List<AssetItem> assets=[];
  List<Goal> goals=[];
  List<Loan> loans=[];
  List<Budget> budgets=[];
  List<RecurringItem> recurring=[];
  bool locked=false;
  final LocalAuthentication auth=LocalAuthentication();
  static const secureStore=FlutterSecureStorage();
  final cipher=AesGcm.with256bits();
  bool pinConfigured=false;
  bool biometricEnabled=false;
  DateTime? backgroundAt;
  String get today=>DateTime.now().toIso8601String().substring(0,10);
  String money(double v)=>'Rs ${v.toStringAsFixed(0).replaceAllMapped(RegExp(r'(\d)(?=(\d{3})+(?!\d))'),(m)=>'${m[1]},')}';
  String id()=>DateTime.now().microsecondsSinceEpoch.toString();

  @override void initState(){super.initState();WidgetsBinding.instance.addObserver(this);load();}
  @override void dispose(){WidgetsBinding.instance.removeObserver(this);super.dispose();}
  @override void didChangeAppLifecycleState(AppLifecycleState state){
    if(state==AppLifecycleState.paused||state==AppLifecycleState.inactive){backgroundAt=DateTime.now();}
    if(state==AppLifecycleState.resumed && backgroundAt!=null){
      final elapsed=DateTime.now().difference(backgroundAt!);
      if(elapsed.inSeconds>=30 && (pinConfigured||biometricEnabled)){setState(()=>locked=true);}
      backgroundAt=null;
    }
  }
  Future<void> load() async {
    final prefs=await SharedPreferences.getInstance();
    pinConfigured=(await secureStore.read(key:'pin_hash'))!=null;
    biometricEnabled=prefs.getBool('biometric_enabled')??false;
    try {
      final encrypted=await prefs.getString('vault_v1');
      if(encrypted!=null){
        final keyText=await secureStore.read(key:'vault_key');
        if(keyText!=null){
          final raw=base64Decode(encrypted);
          final nonce=raw.sublist(0,12);
          final mac=raw.sublist(raw.length-16);
          final body=raw.sublist(12,raw.length-16);
          final box=SecretBox(body,nonce:nonce,mac:Mac(mac));
          final clear=await cipher.decrypt(box,secretKey:SecretKey(base64Decode(keyText)));
          final data=jsonDecode(utf8.decode(clear)) as Map<String,dynamic>;
          accounts=(data['accounts'] as List).map((e)=>Account.fromJson(e)).toList();
          txns=(data['txns'] as List).map((e)=>Txn.fromJson(e)).toList();
          assets=(data['assets'] as List).map((e)=>AssetItem.fromJson(e)).toList();
          goals=(data['goals'] as List).map((e)=>Goal.fromJson(e)).toList();
          loans=(data['loans'] as List).map((e)=>Loan.fromJson(e)).toList();
          budgets=(data['budgets'] as List? ?? []).map((e)=>Budget.fromJson(e)).toList();
          recurring=(data['recurring'] as List? ?? []).map((e)=>RecurringItem.fromJson(e)).toList();
        }
      }
    } catch (_) {
      if(mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Could not unlock the encrypted local data vault. Your data has not been reset.')));
    }
    if(accounts.isEmpty && (await prefs.getString('vault_v1'))==null){
      accounts=[Account('cash','Cash','Cash',25000),Account('bank','Bank account','Bank',125000)];
      txns=[Txn(id(),'Salary','Salary','bank','Income',150000,today),Txn(id(),'Groceries','Food','cash','Expense',8500,today)];
    }
    if(mounted){setState(()=>loaded=true);if(pinConfigured||biometricEnabled)setState(()=>locked=true);await processDueRecurring();await save();}
  }
  Future<void> save() async {
    final prefs=await SharedPreferences.getInstance();
    var keyText=await secureStore.read(key:'vault_key');
    if(keyText==null){final bytes=List<int>.generate(32,(_)=>Random.secure().nextInt(256));keyText=base64Encode(bytes);await secureStore.write(key:'vault_key',value:keyText);}
    final data={
      'accounts':accounts.map((e)=>e.toJson()).toList(),
      'txns':txns.map((e)=>e.toJson()).toList(),
      'assets':assets.map((e)=>e.toJson()).toList(),
      'goals':goals.map((e)=>e.toJson()).toList(),
      'loans':loans.map((e)=>e.toJson()).toList(),
      'budgets':budgets.map((e)=>e.toJson()).toList(),
      'recurring':recurring.map((e)=>e.toJson()).toList(),
    };
    final box=await cipher.encrypt(utf8.encode(jsonEncode(data)),secretKey:SecretKey(base64Decode(keyText)));
    final packed=[...box.nonce,...box.cipherText,...box.mac.bytes];
    await prefs.setString('vault_v1',base64Encode(packed));
    await prefs.setBool('biometric_enabled',biometricEnabled);
  }
  double balance(String accountId) {
    final a=accounts.firstWhere((e)=>e.id==accountId,orElse:()=>Account('x','Unknown','',0));
    double v=a.opening;
    for(final t in txns.where((e)=>e.accountId==accountId)) {
      if(t.type=='Income') v+=t.amount;
      if(t.type=='Expense') v-=t.amount;
    }
    return v;
  }
  double get totalBalance=>accounts.fold(0,(s,a)=>s+balance(a.id));
  double get income=>txns.where((t)=>t.type=='Income'&&t.category!='Transfer').fold(0,(s,t)=>s+t.amount);
  double get expense=>txns.where((t)=>t.type=='Expense'&&t.category!='Transfer').fold(0,(s,t)=>s+t.amount);
  double get assetTotal=>assets.fold(0,(s,a)=>s+a.value);
  double get debt=>loans.where((l)=>l.kind=='Borrowed').fold(0,(s,l)=>s+l.remaining);
  void refresh(){setState((){});save();}

  @override Widget build(BuildContext context) {
    if(!loaded)return const Scaffold(body:Center(child:CircularProgressIndicator()));
    final pages=[
      dashboard(), activity(), accountPage(), assetPage(), plansPage()
    ];
    return Scaffold(
      appBar:AppBar(title:Row(children:[Container(width:34,height:34,decoration:BoxDecoration(color:ink,borderRadius:BorderRadius.circular(11)),child:const Icon(Icons.account_balance_wallet_rounded,color:mint,size:20)),const SizedBox(width:10),const Text('My Finance',style:TextStyle(fontWeight:FontWeight.w800,letterSpacing:-.4))]),actions:[IconButton(onPressed:securitySettings,icon:const Icon(Icons.shield_outlined)),IconButton(onPressed:()=>showAboutDialog(context:context,applicationName:'My Finance',applicationVersion:'1.0.0',children:[const Text('Personal finance tracker. Your data is stored locally on this device.')]),icon:const Icon(Icons.info_outline))]),
      body:locked?lockScreen():pages[tab],
      floatingActionButton:tab==1||tab==2?FloatingActionButton.extended(onPressed:tab==1?addTransaction:addAccount,backgroundColor:ink,foregroundColor:Colors.white,icon:const Icon(Icons.add),label:Text(tab==1?'Add entry':'Add account')):null,
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),backgroundColor:Colors.white,indicatorColor:mint.withOpacity(.18),destinations:const [
        NavigationDestination(icon:Icon(Icons.grid_view_rounded),label:'Home'),
        NavigationDestination(icon:Icon(Icons.receipt_long_rounded),label:'Activity'),
        NavigationDestination(icon:Icon(Icons.account_balance_rounded),label:'Accounts'),
        NavigationDestination(icon:Icon(Icons.diamond_outlined),label:'Assets'),
        NavigationDestination(icon:Icon(Icons.savings_outlined),label:'Plans'),
      ]),
    );
  }

  Widget dashboard()=>ListView(padding:const EdgeInsets.fromLTRB(18,8,18,28),children:[
    const Text('YOUR FINANCIAL OVERVIEW',style:TextStyle(color:Colors.blueGrey,fontSize:11,fontWeight:FontWeight.w800,letterSpacing:1.3)),
    const SizedBox(height:12),
    Container(padding:const EdgeInsets.all(22),decoration:BoxDecoration(gradient:const LinearGradient(colors:[ink,navy],begin:Alignment.topLeft,end:Alignment.bottomRight),borderRadius:BorderRadius.circular(26)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      const Text('Total account balance',style:TextStyle(color:Colors.white70,fontSize:13)),
      const SizedBox(height:8),Text(money(totalBalance),style:const TextStyle(color:Colors.white,fontSize:32,fontWeight:FontWeight.w800,letterSpacing:-1)),
      const SizedBox(height:20),Row(children:[_darkMetric('INCOME',money(income),mint),const Spacer(),_darkMetric('EXPENSES',money(expense),const Color(0xFFFF9D9D))])
    ])),
    const SizedBox(height:18),
    Row(children:[Expanded(child:_metric('Assets',money(assetTotal),Icons.diamond_outlined)),const SizedBox(width:12),Expanded(child:_metric('Borrowed',money(debt),Icons.credit_score))]),
    const SizedBox(height:24),_heading('Cash flow','Income vs expenses'),
    SizedBox(height:180,child:Card(child:Padding(padding:const EdgeInsets.all(16),child:BarChart(BarChartData(maxY:[income,expense,1.0].reduce((a,b)=>a>b?a:b)*1.2,barGroups:[BarChartGroupData(x:0,barRods:[BarChartRodData(toY:income,color:mint,width:28,borderRadius:BorderRadius.circular(6))]),BarChartGroupData(x:1,barRods:[BarChartRodData(toY:expense,color:Colors.redAccent,width:28,borderRadius:BorderRadius.circular(6))])],titlesData:FlTitlesData(leftTitles:const AxisTitles(sideTitles:SideTitles(showTitles:false)),rightTitles:const AxisTitles(sideTitles:SideTitles(showTitles:false)),topTitles:const AxisTitles(sideTitles:SideTitles(showTitles:false)),bottomTitles:AxisTitles(sideTitles:SideTitles(showTitles:true,getTitlesWidget:(v,m)=>Padding(padding:const EdgeInsets.only(top:8),child:Text(v==0?'Income':'Expense',style:const TextStyle(fontSize:11)))))),borderData:FlBorderData(show:false),gridData:const FlGridData(show:false))))))),
    const SizedBox(height:24),_heading('My accounts','${accounts.length} accounts'),
    ...accounts.map((a)=>Card(child:ListTile(leading:_iconFor(a.kind),title:Text(a.name,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text(a.kind),trailing:Text(money(balance(a.id)),style:const TextStyle(fontWeight:FontWeight.w800,color:ink))))),
    const SizedBox(height:18),_heading('Recent activity','View all',onTap:()=>setState(()=>tab=1)),
    ...txns.reversed.take(4).map(transactionTile),
  ]);

  Widget activity()=>ListView(padding:const EdgeInsets.all(18),children:[
    _heading('Transactions','${txns.length} entries'),
    Row(children:[Expanded(child:_metric('Income',money(income),Icons.south_west,color:mint)),const SizedBox(width:10),Expanded(child:_metric('Expenses',money(expense),Icons.north_east,color:Colors.redAccent))]),
    const SizedBox(height:16),
    ...txns.reversed.map(transactionTile),
    const SizedBox(height:12),
    OutlinedButton.icon(onPressed:addTransfer,icon:const Icon(Icons.swap_horiz),label:const Text('Transfer between accounts')),
  ]);
  Widget transactionTile(Txn t)=>Card(child:ListTile(
    leading:CircleAvatar(backgroundColor:(t.type=='Income'?mint:Colors.redAccent).withOpacity(.13),child:Icon(t.type=='Income'?Icons.south_west:Icons.north_east,color:t.type=='Income'?mint:Colors.redAccent)),
    title:Text(t.title,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text('${t.category} • ${accounts.firstWhere((a)=>a.id==t.accountId,orElse:()=>Account('','','',0)).name} • ${t.date}'),
    trailing:Text('${t.type=='Income'?'+':'−'}${money(t.amount)}',style:TextStyle(fontWeight:FontWeight.w800,color:t.type=='Income'?mint:Colors.redAccent)),
    onLongPress:()=>confirmDelete('Delete this transaction?',()=>txns.removeWhere((x)=>x.id==t.id)),
  ));

  Widget accountPage()=>ListView(padding:const EdgeInsets.all(18),children:[
    _heading('Accounts','Manage balances'),
    ...accounts.map((a)=>Card(child:ListTile(leading:_iconFor(a.kind),title:Text(a.name,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text('${a.kind} • Opening ${money(a.opening)}'),trailing:Text(money(balance(a.id)),style:const TextStyle(fontWeight:FontWeight.w800)),onLongPress:()=>confirmDelete('Delete account? Linked records may become unassigned.',()=>accounts.removeWhere((x)=>x.id==a.id))))),
    const SizedBox(height:10),OutlinedButton.icon(onPressed:addTransfer,icon:const Icon(Icons.swap_horiz),label:const Text('Transfer between accounts')),
    const SizedBox(height:8),const Text('Transfers are recorded as paired account adjustments and do not count as income or expense.',style:TextStyle(color:Colors.blueGrey,fontSize:12)),
  ]);

  Widget assetPage()=>ListView(padding:const EdgeInsets.all(18),children:[
    _heading('Assets','${money(assetTotal)} total value'),
    ...assets.map((a)=>Card(child:ListTile(leading:_iconFor(a.kind),title:Text(a.name,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text('${a.kind} • Linked: ${accounts.firstWhere((x)=>x.id==a.accountId,orElse:()=>Account('','','',0)).name}'),trailing:Text(money(a.value),style:const TextStyle(fontWeight:FontWeight.w800)),onLongPress:()=>confirmDelete('Delete asset?',()=>assets.removeWhere((x)=>x.id==a.id))))),
    const SizedBox(height:12),FilledButton.icon(onPressed:addAsset,icon:const Icon(Icons.add),label:const Text('Add asset')),
    const SizedBox(height:8),const Text('Asset values are tracked separately from account cash balances to avoid double counting.',style:TextStyle(color:Colors.blueGrey,fontSize:12)),
  ]);

  Widget plansPage()=>ListView(padding:const EdgeInsets.all(18),children:[
    _heading('Savings goals','${goals.length} goals'),
    ...goals.map((g){final pct=g.target<=0?0:(g.saved/g.target).clamp(0.0,1.0);return Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Row(children:[Expanded(child:Text(g.name,style:const TextStyle(fontWeight:FontWeight.w800))),Text('${(pct*100).round()}%',style:const TextStyle(color:mint,fontWeight:FontWeight.w800))]),
      const SizedBox(height:8),ClipRRect(borderRadius:BorderRadius.circular(20),child:LinearProgressIndicator(value:pct.toDouble(),minHeight:8,backgroundColor:canvas,color:mint)),
      const SizedBox(height:8),Row(children:[Text('${money(g.saved)} saved',style:const TextStyle(fontSize:12,color:Colors.blueGrey)),const Spacer(),Text('Target ${money(g.target)}',style:const TextStyle(fontSize:12,fontWeight:FontWeight.w700))]),
      Align(alignment:Alignment.centerRight,child:TextButton(onPressed:()=>contributeGoal(g),child:const Text('Add savings'))),
    ])));}),
    OutlinedButton.icon(onPressed:addGoal,icon:const Icon(Icons.add),label:const Text('Create savings goal')),
    const SizedBox(height:24),_heading('Loans','${loans.length} records'),
    ...loans.map((l)=>Card(child:ListTile(leading:Icon(l.kind=='Borrowed'?Icons.call_received:Icons.call_made,color:l.kind=='Borrowed'?Colors.redAccent:mint),title:Text(l.name,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text('${l.kind} • Linked: ${accounts.firstWhere((x)=>x.id==l.accountId,orElse:()=>Account('','','',0)).name}'),trailing:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.end,children:[Text(money(l.remaining),style:const TextStyle(fontWeight:FontWeight.w800)),Text('of ${money(l.principal)}',style:const TextStyle(fontSize:10,color:Colors.blueGrey))]),onTap:()=>repayLoan(l),onLongPress:()=>confirmDelete('Delete loan record?',()=>loans.removeWhere((x)=>x.id==l.id))))),
    OutlinedButton.icon(onPressed:addLoan,icon:const Icon(Icons.add),label:const Text('Add loan')),
    const SizedBox(height:20),_heading('Monthly budgets','${budgets.length} categories'),
    ...budgets.map((b){final used=txns.where((t)=>t.type=='Expense'&&t.category==b.category&&t.date.startsWith(DateTime.now().toIso8601String().substring(0,7))).fold(0.0,(s,t)=>s+t.amount);final pct=b.limit<=0?0:(used/b.limit).clamp(0.0,1.0);return Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Row(children:[Expanded(child:Text(b.category,style:const TextStyle(fontWeight:FontWeight.w700))),Text('${money(used)} / ${money(b.limit)}')]),const SizedBox(height:7),ClipRRect(borderRadius:BorderRadius.circular(10),child:LinearProgressIndicator(value:pct.toDouble(),minHeight:7,color:pct>=1?Colors.redAccent:mint,backgroundColor:canvas))])));}),
    OutlinedButton.icon(onPressed:addBudget,icon:const Icon(Icons.add),label:const Text('Set monthly budget')),
    const SizedBox(height:20),_heading('Recurring entries','${recurring.length} scheduled'),
    ...recurring.map((r)=>Card(child:ListTile(leading:const Icon(Icons.autorenew,color:mint),title:Text(r.title,style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text('${r.frequency} • Next: ${r.nextDate}'),trailing:Text(money(r.amount)),onLongPress:()=>confirmDelete('Delete recurring rule?',()=>recurring.removeWhere((x)=>x.id==r.id))))),
    OutlinedButton.icon(onPressed:addRecurring,icon:const Icon(Icons.add),label:const Text('Add recurring rule')),
    const SizedBox(height:20),_heading('Reports','Export your records'),
    OutlinedButton.icon(onPressed:exportPdf,icon:const Icon(Icons.picture_as_pdf_outlined),label:const Text('Share PDF report')),
    OutlinedButton.icon(onPressed:exportExcel,icon:const Icon(Icons.table_chart_outlined),label:const Text('Share Excel workbook')),
    OutlinedButton.icon(onPressed:exportBackup,icon:const Icon(Icons.backup_outlined),label:const Text('Create JSON backup')),
    OutlinedButton.icon(onPressed:restoreBackup,icon:const Icon(Icons.restore),label:const Text('Restore from JSON backup')),
    const SizedBox(height:8),const Text('Tap a loan to record a repayment. Repayment is posted to its linked account.',style:TextStyle(color:Colors.blueGrey,fontSize:12)),
  ]);

  Widget _heading(String title,String trailing,{VoidCallback? onTap})=>Padding(padding:const EdgeInsets.only(bottom:10),child:Row(children:[Text(title,style:const TextStyle(fontSize:19,fontWeight:FontWeight.w800,color:ink,letterSpacing:-.4)),const Spacer(),if(onTap!=null)TextButton(onPressed:onTap,child:Text(trailing))else Text(trailing,style:const TextStyle(fontSize:11,color:Colors.blueGrey))]));
  Widget _darkMetric(String label,String value,Color color)=>Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(label,style:const TextStyle(color:Colors.white60,fontSize:10,letterSpacing:1)),const SizedBox(height:4),Text(value,style:TextStyle(color:color,fontWeight:FontWeight.w800,fontSize:16))]);
  Widget _metric(String label,String value,IconData icon,{Color color=mint})=>Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(20)),child:Row(children:[Container(padding:const EdgeInsets.all(9),decoration:BoxDecoration(color:color.withOpacity(.13),borderRadius:BorderRadius.circular(12)),child:Icon(icon,color:color,size:19)),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(label,style:const TextStyle(fontSize:11,color:Colors.blueGrey)),Text(value,style:const TextStyle(fontSize:15,fontWeight:FontWeight.w800,color:ink),overflow:TextOverflow.ellipsis)]))]));
  Widget _iconFor(String kind)=>CircleAvatar(backgroundColor:mint.withOpacity(.13),child:Icon(kind=='Bank'?Icons.account_balance:kind=='Cash'?Icons.payments_outlined:Icons.credit_card,color:mint));

  Future<void> confirmDelete(String msg,VoidCallback action)async{final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Confirm'),content:Text(msg),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Delete'))]));if(ok==true){setState(action);save();}}
  Future<void> addAccount()async{final name=TextEditingController(),opening=TextEditingController(text:'0');String kind='Bank';final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('New account'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Account name')),TextField(controller:opening,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Opening balance')),DropdownButtonFormField(value:kind,items:['Bank','Cash','Wallet'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>kind=v??'Bank')]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Save'))]));if(ok==true&&name.text.trim().isNotEmpty){accounts.add(Account(id(),name.text.trim(),kind,double.tryParse(opening.text)??0));refresh();}}
  Future<void> addTransaction()async{if(accounts.isEmpty)return;final title=TextEditingController(),amount=TextEditingController();String type='Expense',cat='General',account=accounts.first.id;final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,ss)=>AlertDialog(title:const Text('Add transaction'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:title,decoration:const InputDecoration(labelText:'Description')),TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Amount (PKR)')),DropdownButtonFormField(value:type,items:['Income','Expense'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>ss(()=>type=v??'Expense')),DropdownButtonFormField(value:cat,items:(type=='Income'?['Salary','Business','Gift','Other']:['Food','Transport','Bills','Shopping','Health','General']).map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>ss(()=>cat=v??'General')),DropdownButtonFormField(value:account,items:accounts.map((x)=>DropdownMenuItem(value:x.id,child:Text(x.name))).toList(),onChanged:(v)=>ss(()=>account=v??accounts.first.id))])),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Save'))])));final n=double.tryParse(amount.text);if(ok==true&&title.text.trim().isNotEmpty&&n!=null&&n>0){txns.add(Txn(id(),title.text.trim(),cat,account,type,n,today));refresh();}}
  Future<void> addTransfer()async{if(accounts.length<2){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Create at least two accounts first.')));return;}final amount=TextEditingController();String from=accounts[0].id,to=accounts[1].id;final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,ss)=>AlertDialog(title:const Text('Transfer funds'),content:Column(mainAxisSize:MainAxisSize.min,children:[DropdownButtonFormField(value:from,items:accounts.map((x)=>DropdownMenuItem(value:x.id,child:Text('From: ${x.name}'))).toList(),onChanged:(v)=>ss(()=>from=v??from)),DropdownButtonFormField(value:to,items:accounts.map((x)=>DropdownMenuItem(value:x.id,child:Text('To: ${x.name}'))).toList(),onChanged:(v)=>ss(()=>to=v??to)),TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Amount (PKR)'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Transfer'))])));final n=double.tryParse(amount.text);if(ok==true&&from!=to&&n!=null&&n>0){txns.add(Txn(id(),'Transfer out','Transfer',from,'Expense',n,today));txns.add(Txn(id(),'Transfer in','Transfer',to,'Income',n,today));refresh();}}
  Future<void> addAsset()async{if(accounts.isEmpty)return;final name=TextEditingController(),value=TextEditingController();String kind='Property',account=accounts.first.id;final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,ss)=>AlertDialog(title:const Text('Add asset'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Asset name')),TextField(controller:value,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Current value (PKR)')),DropdownButtonFormField(value:kind,items:['Property','Gold','Vehicle','Investment','Other'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>ss(()=>kind=v??kind)),DropdownButtonFormField(value:account,items:accounts.map((x)=>DropdownMenuItem(value:x.id,child:Text(x.name))).toList(),onChanged:(v)=>ss(()=>account=v??account))]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Save'))])));final n=double.tryParse(value.text);if(ok==true&&name.text.trim().isNotEmpty&&n!=null&&n>=0){assets.add(AssetItem(id(),name.text.trim(),account,kind,n));refresh();}}
  Future<void> addGoal()async{if(accounts.isEmpty)return;final name=TextEditingController(),target=TextEditingController();String account=accounts.first.id;final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,ss)=>AlertDialog(title:const Text('Savings goal'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Goal name')),TextField(controller:target,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Target (PKR)')),DropdownButtonFormField(value:account,items:accounts.map((x)=>DropdownMenuItem(value:x.id,child:Text(x.name))).toList(),onChanged:(v)=>ss(()=>account=v??account))]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Create'))])));final n=double.tryParse(target.text);if(ok==true&&name.text.trim().isNotEmpty&&n!=null&&n>0){goals.add(Goal(id(),name.text.trim(),account,n,0));refresh();}}
  Future<void> contributeGoal(Goal g)async{final amount=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:Text('Add to ${g.name}'),content:TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Amount (PKR)')),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Add'))]));final n=double.tryParse(amount.text);if(ok==true&&n!=null&&n>0&&n<=balance(g.accountId)){g.saved+=n;txns.add(Txn(id(),'Savings: ${g.name}','Savings',g.accountId,'Expense',n,today));refresh();}}
  Future<void> addLoan()async{if(accounts.isEmpty)return;final name=TextEditingController(),principal=TextEditingController();String kind='Borrowed',account=accounts.first.id;final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,ss)=>AlertDialog(title:const Text('Add loan'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'Loan name / person')),TextField(controller:principal,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Amount (PKR)')),DropdownButtonFormField(value:kind,items:['Borrowed','Lent'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>ss(()=>kind=v??kind)),DropdownButtonFormField(value:account,items:accounts.map((x)=>DropdownMenuItem(value:x.id,child:Text(x.name))).toList(),onChanged:(v)=>ss(()=>account=v??account))]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Save'))])));final n=double.tryParse(principal.text);if(ok==true&&name.text.trim().isNotEmpty&&n!=null&&n>0){loans.add(Loan(id(),name.text.trim(),account,kind,n,n));if(kind=='Borrowed')txns.add(Txn(id(),'Loan received: ${name.text}','Loan',account,'Income',n,today));else txns.add(Txn(id(),'Loan given: ${name.text}','Loan',account,'Expense',n,today));refresh();}}
  Future<void> repayLoan(Loan l)async{final amount=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:Text(l.kind=='Borrowed'?'Repay loan':'Receive repayment'),content:TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Amount (PKR)')),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Record'))]));final n=double.tryParse(amount.text);if(ok==true&&n!=null&&n>0&&n<=l.remaining){l.remaining-=n;txns.add(Txn(id(),l.kind=='Borrowed'?'Loan repayment: ${l.name}':'Loan received: ${l.name}','Loan',l.accountId,l.kind=='Borrowed'?'Expense':'Income',n,today));refresh();}}

  Widget lockScreen()=>Center(child:Padding(padding:const EdgeInsets.all(28),child:Column(mainAxisSize:MainAxisSize.min,children:[const Icon(Icons.lock_outline,size:54,color:ink),const SizedBox(height:16),const Text('My Finance is locked',style:TextStyle(fontSize:22,fontWeight:FontWeight.w800)),const SizedBox(height:8),const Text('Authenticate to view your financial information.',textAlign:TextAlign.center),const SizedBox(height:18),FilledButton.icon(onPressed:unlock,icon:const Icon(Icons.face),label:const Text('Unlock with biometrics'))])));
  Future<void> securitySettings()async{
    final pin=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Set app PIN'),content:TextField(controller:pin,keyboardType:TextInputType.number,obscureText:true,maxLength:6,decoration:const InputDecoration(labelText:'Create a 4–6 digit PIN')),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Save PIN'))]));
    if(ok==true&&RegExp(r'^\d{4,6}$').hasMatch(pin.text)){
      final salt=List<int>.generate(16,(_)=>Random.secure().nextInt(256));
      final mac=await Hmac.sha256().calculateMac(utf8.encode(pin.text),secretKey:SecretKey(salt));
      await secureStore.write(key:'pin_salt',value:base64Encode(salt));
      await secureStore.write(key:'pin_hash',value:base64Encode(mac.bytes));
      pinConfigured=true;
    } else if(ok==true){
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('PIN must contain 4 to 6 digits.')));
    }
    final p=await SharedPreferences.getInstance();
    final enableBio=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Biometric unlock'),content:const Text('Also enable Face ID / Touch ID / Android biometrics?'),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Skip')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Enable'))]));
    if(enableBio==true){try{biometricEnabled=await auth.isDeviceSupported();if(biometricEnabled){final passed=await auth.authenticate(localizedReason:'Enable biometric unlock for My Finance');if(!passed)biometricEnabled=false;}}catch(_){biometricEnabled=false;}}
    await p.setBool('biometric_enabled',biometricEnabled);
    await save();if(mounted)setState(()=>locked=false);
  }
  Future<void> unlock()async{
    if(biometricEnabled){try{final passed=await auth.authenticate(localizedReason:'Unlock My Finance');if(passed){setState(()=>locked=false);return;}}catch(_){}}
    final pin=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Enter PIN'),content:TextField(controller:pin,keyboardType:TextInputType.number,obscureText:true,maxLength:6,decoration:const InputDecoration(labelText:'App PIN')),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Unlock'))]));
    if(ok==true){
      final salt=await secureStore.read(key:'pin_salt'), expected=await secureStore.read(key:'pin_hash');
      if(salt!=null&&expected!=null){
        final mac=await Hmac.sha256().calculateMac(utf8.encode(pin.text),secretKey:SecretKey(base64Decode(salt)));
        if(base64Encode(mac.bytes)==expected){setState(()=>locked=false);return;}
      }
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Incorrect PIN. Try again.')));
    }
  }
  Future<void> processDueRecurring()async{
    final now=DateTime.now();bool changed=false;
    for(final r in recurring){
      DateTime? due=DateTime.tryParse(r.nextDate);int guard=0;
      while(due!=null&&!due.isAfter(now)&&guard<24){
        txns.add(Txn(id(),r.title,r.category,r.accountId,r.type,r.amount,due.toIso8601String().substring(0,10)));
        due=switch(r.frequency){'Weekly'=>due.add(const Duration(days:7)),'Yearly'=>DateTime(due.year+1,due.month,due.day),_=>DateTime(due.year,due.month+1,due.day)};
        guard++;changed=true;
      }
      if(due!=null&&guard>0)r.nextDate=due.toIso8601String().substring(0,10);
    }
    if(changed){await save();}
  }
  Future<void> exportBackup()async{
    final backup={'version':1,'createdAt':DateTime.now().toIso8601String(),'accounts':accounts.map((e)=>e.toJson()).toList(),'txns':txns.map((e)=>e.toJson()).toList(),'assets':assets.map((e)=>e.toJson()).toList(),'goals':goals.map((e)=>e.toJson()).toList(),'loans':loans.map((e)=>e.toJson()).toList(),'budgets':budgets.map((e)=>e.toJson()).toList(),'recurring':recurring.map((e)=>e.toJson()).toList()};
    final dir=await getTemporaryDirectory();final file=File('${dir.path}/my_finance_backup.json');await file.writeAsString(jsonEncode(backup));await Share.shareXFiles([XFile(file.path)],text:'My Finance backup. Store it in a secure location.');
  }
  Future<void> restoreBackup()async{
    final result=await FilePicker.platform.pickFiles(type:FileType.custom,allowedExtensions:['json'],withData:true);
    if(result==null||result.files.single.bytes==null)return;
    try{
      final data=jsonDecode(utf8.decode(result.files.single.bytes!)) as Map<String,dynamic>;
      accounts=(data['accounts'] as List).map((e)=>Account.fromJson(e)).toList();
      txns=(data['txns'] as List).map((e)=>Txn.fromJson(e)).toList();
      assets=(data['assets'] as List).map((e)=>AssetItem.fromJson(e)).toList();
      goals=(data['goals'] as List).map((e)=>Goal.fromJson(e)).toList();
      loans=(data['loans'] as List).map((e)=>Loan.fromJson(e)).toList();
      budgets=(data['budgets'] as List? ?? []).map((e)=>Budget.fromJson(e)).toList();
      recurring=(data['recurring'] as List? ?? []).map((e)=>RecurringItem.fromJson(e)).toList();
      await save();if(mounted)setState((){});
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Backup restored successfully.')));
    }catch(_){if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Invalid backup file.')));}
  }
  Future<void> addBudget()async{final cat=TextEditingController(),limit=TextEditingController();final ok=await showDialog<bool>(context:context,builder:(c)=>AlertDialog(title:const Text('Monthly budget'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:cat,decoration:const InputDecoration(labelText:'Expense category')),TextField(controller:limit,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Monthly limit (PKR)'))]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Save'))]));final n=double.tryParse(limit.text);if(ok==true&&cat.text.trim().isNotEmpty&&n!=null&&n>0){budgets.add(Budget(id(),cat.text.trim(),n));refresh();}}
  Future<void> addRecurring()async{if(accounts.isEmpty)return;final title=TextEditingController(),amount=TextEditingController();String account=accounts.first.id,type='Expense',frequency='Monthly',category='Bills';final ok=await showDialog<bool>(context:context,builder:(c)=>StatefulBuilder(builder:(c,ss)=>AlertDialog(title:const Text('Recurring transaction'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:title,decoration:const InputDecoration(labelText:'Description')),TextField(controller:amount,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'Amount (PKR)')),DropdownButtonFormField(value:type,items:['Income','Expense'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>ss(()=>type=v??type)),DropdownButtonFormField(value:frequency,items:['Weekly','Monthly','Yearly'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>ss(()=>frequency=v??frequency)),DropdownButtonFormField(value:account,items:accounts.map((x)=>DropdownMenuItem(value:x.id,child:Text(x.name))).toList(),onChanged:(v)=>ss(()=>account=v??account))]),actions:[TextButton(onPressed:()=>Navigator.pop(c,false),child:const Text('Cancel')),FilledButton(onPressed:()=>Navigator.pop(c,true),child:const Text('Save rule'))])));final n=double.tryParse(amount.text);if(ok==true&&title.text.trim().isNotEmpty&&n!=null&&n>0){recurring.add(RecurringItem(id(),title.text.trim(),category,account,type,n,frequency,today));refresh();}}
  Future<void> exportPdf()async{final doc=pw.Document();doc.addPage(pw.MultiPage(build:(c)=>[pw.Header(level:0,child:pw.Text('My Finance — Financial Report')),pw.Text('Generated: $today'),pw.SizedBox(height:12),pw.Text('Total account balance: ${money(totalBalance)}'),pw.Text('Income: ${money(income)}'),pw.Text('Expenses: ${money(expense)}'),pw.Text('Assets: ${money(assetTotal)}'),pw.Text('Borrowed loans remaining: ${money(debt)}'),pw.SizedBox(height:18),pw.Header(level:1,child:pw.Text('Transactions')),pw.TableHelper.fromTextArray(headers:['Date','Description','Type','Amount (PKR)'],data:txns.map((t)=>[t.date,t.title,t.type,money(t.amount)]).toList())]));final dir=await getTemporaryDirectory();final file=File('${dir.path}/my_finance_report.pdf');await file.writeAsBytes(await doc.save());await Share.shareXFiles([XFile(file.path)],text:'My Finance PDF report');}
  Future<void> exportExcel()async{final book=Excel.createExcel();final sheet=book['Transactions'];sheet.appendRow([TextCellValue('Date'),TextCellValue('Description'),TextCellValue('Category'),TextCellValue('Type'),TextCellValue('Account'),TextCellValue('Amount PKR')]);for(final t in txns){final accountName=accounts.firstWhere((a)=>a.id==t.accountId,orElse:()=>Account('','','',0)).name;sheet.appendRow([TextCellValue(t.date),TextCellValue(t.title),TextCellValue(t.category),TextCellValue(t.type),TextCellValue(accountName),DoubleCellValue(t.amount)]);}final summary=book['Summary'];summary.appendRow([TextCellValue('Metric'),TextCellValue('PKR')]);summary.appendRow([TextCellValue('Account balance'),DoubleCellValue(totalBalance)]);summary.appendRow([TextCellValue('Income'),DoubleCellValue(income)]);summary.appendRow([TextCellValue('Expenses'),DoubleCellValue(expense)]);summary.appendRow([TextCellValue('Assets'),DoubleCellValue(assetTotal)]);final dir=await getTemporaryDirectory();final file=File('${dir.path}/my_finance_report.xlsx');await file.writeAsBytes(book.encode()!);await Share.shareXFiles([XFile(file.path)],text:'My Finance Excel report');}

}
