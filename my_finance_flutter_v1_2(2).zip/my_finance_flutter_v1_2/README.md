# My Finance v1.2 — secure cross-platform starter

## Implemented in v1.2
- PIN setup and PIN fallback unlock (4–6 digits; salted HMAC-SHA256 verifier)
- Optional Face ID / Touch ID / Android biometric unlock
- Automatic lock after app has been backgrounded for 30 seconds
- Encrypted local finance vault (AES-256-GCM); vault key stored via iOS Keychain / Android Keystore-backed secure storage
- JSON backup export and restore
- Due recurring transactions are posted when the app opens (catch-up for missed due dates)
- PDF and Excel report export
- Monthly budgets, cash-flow chart, accounts, transfers, assets, savings goals, loans and repayments

## Run
1. Install Flutter SDK.
2. Extract this ZIP and open the project.
3. Run `flutter pub get`.
4. Run `flutter run`.
5. For iOS use macOS/Xcode; for Android use Android Studio.

## iOS setup
Add this key to `ios/Runner/Info.plist`:
`<key>NSFaceIDUsageDescription</key><string>Use Face ID to unlock My Finance.</string>`
Then run `cd ios && pod install`.

## Cloud sync / iCloud
Cross-platform synchronization is intentionally not activated without a configured backend and project credentials. iCloud is Apple-only and cannot synchronize Android. Recommended production architecture: Firebase Authentication + Cloud Firestore with per-user security rules, encrypted backups, conflict resolution, and opt-in sync. To finish this part, create a Firebase project and run FlutterFire CLI (`flutterfire configure`) for both iOS and Android, then enable Authentication and Firestore. Do not put service-account secrets in the app.

## Important release caveats
- This is source code, not a compiled/signed IPA or APK and not published to App Store / Play Store.
- Review dependency versions and run `flutter pub get`, `flutter analyze`, unit tests, and physical-device tests before use.
- The current encrypted vault is a single encrypted JSON record in app preferences; migrate to a dedicated encrypted database for large datasets.
- PIN lockout/rate limiting, account recovery, secure cloud merge and automated background execution/notifications still need production implementation.
- Recurring transactions catch up when the app is opened; they do not execute while the app is force-closed. Add platform background scheduling and local notifications for that.
- JSON backup contains financial data in readable form. Store exported backups in a protected location; encryption/password-protected export should be added before sharing sensitive backups.
- The code does not connect to real banks or payment networks.
